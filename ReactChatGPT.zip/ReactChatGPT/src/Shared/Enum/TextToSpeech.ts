export const enum TextToSpeechOperation{
    SPEAK='speak',
    PAUSE='pause',
    RESUME='resume'
}