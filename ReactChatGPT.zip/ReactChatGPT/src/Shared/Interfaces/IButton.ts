export interface IButton extends React.ComponentPropsWithoutRef<"button"> {
    specialProp?: string;
  }