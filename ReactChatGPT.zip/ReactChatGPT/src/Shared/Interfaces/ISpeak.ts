import { TextToSpeechOperation } from "../Enum/TextToSpeech";

export interface ISpeak{
    opearation:TextToSpeechOperation,
    title:string
}