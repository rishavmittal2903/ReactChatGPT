export interface IHeading extends React.HTMLProps<HTMLHeadingElement> {
    type?: string;
    className?:string;
  }