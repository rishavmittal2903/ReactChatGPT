export interface ITextarea extends React.HTMLProps<HTMLTextAreaElement> {
    isLoading?: boolean;
  }