import "./App.css";
import GenericQuestionForum from "./Components/GenericQuestionForum";
const App = () => {
  return (
    <div className="App">
      <GenericQuestionForum/>
    </div>
  );
};

export default App;
